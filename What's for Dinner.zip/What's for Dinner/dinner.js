const restaurants = [
    { name: "Eat n Park", type: ["Diner", "Chain", "Buffet"] },
    { name: "Tres Amigos", type: "Mexican"},
    { name: "Bruno's", type: "Italian"},
    { name: "Spaghetti Bender's", type: "Italian"},
    { name: "Umi", type: ["Chinese", "Hibachi", "Sushi"] },
    { name: "King Buffet", type: ["Chinese", "Buffet"] },
    { name: "Casa Jalisco", type: "Mexican"},
    { name: "Ruby Tuesday", type: ["]Chain", "Diner", "Buffet"] },
    { name: "Italian Village", type: "Pizza"},
    { name: "Romeo's", type: ["Pizza", "Italian"] },
    { name: "The Coney", type: "Bar"},
    { name: "Culpepper's", type: "Bar"},
    { name: "Takumi", type: ["Ramen", "Sushi"] },
    { name: "Siam Kitchen", type: ["Thai", "Ramen"] },
    { name: "TeeRak", type: ["Thai", "Ramen"] },
    { name: "Pan Asia", type: "Chinese"},
    { name: "China King", type: "Chinese"},
    { name: "Brunzies", type: "Bar"},
    { name: "9th Street Deli", type: "Sandwich"},
    { name: "Valley Dairy", type: ["Diner", "Chain"] },
    { name: "Primanti's", type: ["Bar", "Chain"] },
    { name: "Texas Roadhouse", type: ["Steak", "Chain"] },
    { name: "Rose Inn", type: "Bar"},
    { name: "Benjamin's", type: ["Italian", "Steak"] },
    { name: "Venice", type: "Pizza"},
    { name: "Coy's", type: "Pizza"},
    { name: "Hoss's", type: ["Steak", "Chain", "Buffet"] },
    { name: "Naps", type: "Italian"},
    { name: "Jersey Mike's", type: ["Sandwich", "Chain"] },
    { name: "Chipotle", type: ["Mexican", "Chain"] },
    { name: "Perkins", type: ["Diner", "Chain"] },
    { name: "Z Buffet", type: ["Chinese", "Buffet"] },
    { name: "Home", type: "Free"},
];

function pickOne() {
    const random = restaurants[Math.floor(Math.random() * restaurants.length)];
    document.getElementById("result").innerText = `Go to: ${random.name}`;
}

function pickTwo() {
    const shuffled = restaurants.sort(() => 0.5 - Math.random());
    const picks = shuffled.slice(0, 2).map(r => r.name).join(" or ");
    document.getElementById("result").innerText = `Choose between: ${picks}`;

}

function pickByType(type) {
  const filtered = restaurants.filter(r => r.type.includes(type));
  if (filtered.length === 0) {
    document.getElementById("result").innerText = `No restaurants found for: ${type}`;
    return;
  }

  const random = filtered[Math.floor(Math.random() * filtered.length)];
  document.getElementById("result").innerText = `Go to: ${random.name} (${type})`;
}